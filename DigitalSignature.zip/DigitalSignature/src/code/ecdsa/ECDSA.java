package code.ecdsa;

import org.apache.commons.codec.binary.Hex;
import sun.misc.BASE64Encoder;

import java.security.*;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class ECDSA {
    private static String data = "security ecdsa";

    public static void main(String[] args) {
        ECDSAGenerateKey ecdsaGenerateKey = generateKey();
        System.out.println("密钥初始化完成");
        System.out.println("私钥：" + new BASE64Encoder().encodeBuffer(ecdsaGenerateKey.getEcPrivateKey().getEncoded()));
        System.out.println("公钥：" + new BASE64Encoder().encodeBuffer(ecdsaGenerateKey.getEcPublicKey().getEncoded()));
        byte[] signatureResult = signature(ecdsaGenerateKey.getEcPrivateKey());
        System.out.println("签名完成\n签名结果：" + Hex.encodeHexString(signatureResult));       //此处需要 commons-codec 包
        Boolean verificationResult = signatureVerification(ecdsaGenerateKey.getEcPublicKey(), signatureResult);
        System.out.println("验证完成\n验证结果：" + (verificationResult ? "验证成功" : "验证失败"));
    }

    /**
     * @author: 韭菜馅糖包  
     * @date: 2019/8/14 15:21
     * @since: JDK 1.8
     * 
     * @description: 密钥初始化
     * @param: []
     * @return: code.ecdsa.ECDSAGenerateKey
     */
    private static ECDSAGenerateKey generateKey(){
        try {
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("EC");
            keyPairGenerator.initialize(256);  //key 长度
            KeyPair keyPair = keyPairGenerator.generateKeyPair();

            ECPrivateKey ecPrivateKey = (ECPrivateKey) keyPair.getPrivate();
            ECPublicKey ecPublicKey = (ECPublicKey) keyPair.getPublic();

            return new ECDSAGenerateKey(ecPrivateKey, ecPublicKey);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * @author: 韭菜馅糖包  
     * @date: 2019/8/14 15:22
     * @since: JDK 1.8
     * 
     * @description: 签名（私钥）
     * @param: [ecPrivateKey]
     * @return: byte[]
     */
    private static byte[] signature(ECPrivateKey ecPrivateKey){
        PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(ecPrivateKey.getEncoded());

        try {
            KeyFactory keyFactory = KeyFactory.getInstance("EC");
            PrivateKey privateKey = keyFactory.generatePrivate(pkcs8EncodedKeySpec);

            Signature signature = Signature.getInstance("SHA1withECDSA");
            signature.initSign(privateKey);
            signature.update(data.getBytes());
            byte[] signatureResult = signature.sign();

            return signatureResult;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * @author: 韭菜馅糖包  
     * @date: 2019/8/14 15:23
     * @since: JDK 1.8
     * 
     * @description: 签名验证（公钥）
     * @param: [ecPublicKey, signatureResult]
     * @return: java.lang.Boolean
     */
    private static Boolean signatureVerification(ECPublicKey ecPublicKey, byte[] signatureResult){
        X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(ecPublicKey.getEncoded());
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("EC");
            PublicKey publicKey = keyFactory.generatePublic(x509EncodedKeySpec);
            Signature signature = Signature.getInstance("SHA1withECDSA");
            signature.initVerify(publicKey);
            signature.update(data.getBytes());
            return signature.verify(signatureResult);
        } catch (Exception e) {
            e.printStackTrace();
            return true;
        }
    }
}
