package code.ecdsa;

import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;

public class ECDSAGenerateKey {
    private ECPrivateKey ecPrivateKey;

    private ECPublicKey ecPublicKey;

    public ECDSAGenerateKey(ECPrivateKey ecPrivateKey, ECPublicKey ecPublicKey) {
        this.ecPrivateKey = ecPrivateKey;
        this.ecPublicKey = ecPublicKey;
    }

    public ECPrivateKey getEcPrivateKey() {
        return ecPrivateKey;
    }

    public void setEcPrivateKey(ECPrivateKey ecPrivateKey) {
        this.ecPrivateKey = ecPrivateKey;
    }

    public ECPublicKey getEcPublicKey() {
        return ecPublicKey;
    }

    public void setEcPublicKey(ECPublicKey ecPublicKey) {
        this.ecPublicKey = ecPublicKey;
    }
}
