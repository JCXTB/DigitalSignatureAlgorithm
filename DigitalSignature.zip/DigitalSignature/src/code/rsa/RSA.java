package code.rsa;

import org.apache.commons.codec.binary.Hex;
import sun.misc.BASE64Encoder;

import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class RSA {
    private static String data = "security rsa";

    public static void main(String[] args){
        RSAGenerateKey rsaGenerateKey = generateKey();
        System.out.println("密钥初始化完成");
        System.out.println("私钥：" + new BASE64Encoder().encodeBuffer(rsaGenerateKey.getRsaPrivateKey().getEncoded()));
        System.out.println("公钥：" + new BASE64Encoder().encodeBuffer(rsaGenerateKey.getRsaPublicKey().getEncoded()));
        byte[] signatureResult = signature(rsaGenerateKey.getRsaPrivateKey());
        System.out.println("签名完成\n签名结果：" + Hex.encodeHexString(signatureResult));       //此处需要 commons-codec 包
        Boolean verificationResult = signatureVerification(rsaGenerateKey.getRsaPublicKey(), signatureResult);
        System.out.println("验证完成\n验证结果：" + (verificationResult ? "验证成功" : "验证失败"));
    }

    /**
     * @author: 韭菜馅糖包
     * @date: 2019/8/14 10:56
     * @since: JDK 1.8
     *
     * @description: 密钥初始化
     * @param: []
     * @return: code.rsa.RSAGenerateKey
     */
    private static RSAGenerateKey generateKey(){
        try {
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
            keyPairGenerator.initialize(1024);  //key 长度
            KeyPair keyPair = keyPairGenerator.generateKeyPair();

            RSAPrivateKey rsaPrivateKey = (RSAPrivateKey) keyPair.getPrivate();
            RSAPublicKey rsaPublicKey = (RSAPublicKey) keyPair.getPublic();

            return new RSAGenerateKey(rsaPrivateKey, rsaPublicKey);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * @author: 韭菜馅糖包
     * @date: 2019/8/14 10:56
     * @since: JDK 1.8
     *
     * @description: 签名（私钥）
     * @param: [rsaPrivateKey]
     * @return: byte[]
     */
    private static byte[] signature(RSAPrivateKey rsaPrivateKey){
        PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(rsaPrivateKey.getEncoded());

        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PrivateKey privateKey = keyFactory.generatePrivate(pkcs8EncodedKeySpec);

            Signature signature = Signature.getInstance("MD5withRSA");
            signature.initSign(privateKey);
            signature.update(data.getBytes());
            byte[] signatureResult = signature.sign();

            return signatureResult;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

   /**
    * @author: 韭菜馅糖包
    * @date: 2019/8/14 11:04
    * @since: JDK 1.8
    * 
    * @description: 签名验证（公钥）
    * @param: [rsaPublicKey, signatureResult]
    * @return: java.lang.Boolean
    */
    private static Boolean signatureVerification(RSAPublicKey rsaPublicKey, byte[] signatureResult){
        X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(rsaPublicKey.getEncoded());
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PublicKey publicKey = keyFactory.generatePublic(x509EncodedKeySpec);
            Signature signature = Signature.getInstance("MD5withRSA");
            signature.initVerify(publicKey);
            signature.update(data.getBytes());
            return signature.verify(signatureResult);
        } catch (Exception e) {
            e.printStackTrace();
            return true;
        }
    }
}
