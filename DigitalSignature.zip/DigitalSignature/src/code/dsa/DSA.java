package code.dsa;

import org.apache.commons.codec.binary.Hex;
import sun.misc.BASE64Encoder;

import java.security.*;
import java.security.interfaces.DSAPrivateKey;
import java.security.interfaces.DSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class DSA {
    private static String data = "security dsa";

    public static void main(String[] args) {
        DSAGenerateKey dsaGenerateKey = generateKey();
        System.out.println("密钥初始化完成");
        System.out.println("私钥：" + new BASE64Encoder().encodeBuffer(dsaGenerateKey.getDsaPrivateKey().getEncoded()));
        System.out.println("公钥：" + new BASE64Encoder().encodeBuffer(dsaGenerateKey.getDsaPublicKey().getEncoded()));
        byte[] signatureResult = signature(dsaGenerateKey.getDsaPrivateKey());
        System.out.println("签名完成\n签名结果：" + Hex.encodeHexString(signatureResult));       //此处需要 commons-codec 包
        Boolean verificationResult = signatureVerification(dsaGenerateKey.getDsaPublicKey(), signatureResult);
        System.out.println("验证完成\n验证结果：" + (verificationResult ? "验证成功" : "验证失败"));
    }

    /**
     * @author: 韭菜馅糖包
     * @date: 2019/8/14 13:44
     * @since: JDK 1.8
     *
     * @description: 密钥初始化
     * @param: []
     * @return: code.dsa.ECDSAGenerateKey
     */
    private static DSAGenerateKey generateKey(){
        try {
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("DSA");
            keyPairGenerator.initialize(1024);  //key 长度
            KeyPair keyPair = keyPairGenerator.generateKeyPair();

            DSAPrivateKey dsaPrivateKey = (DSAPrivateKey) keyPair.getPrivate();
            DSAPublicKey dsaPublicKey = (DSAPublicKey) keyPair.getPublic();

            return new DSAGenerateKey(dsaPrivateKey, dsaPublicKey);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * @author: 韭菜馅糖包
     * @date: 2019/8/14 13:54
     * @since: JDK 1.8
     *
     * @description: 签名（私钥）
     * @param: [dsaPrivateKey]
     * @return: byte[]
     */
    private static byte[] signature(DSAPrivateKey dsaPrivateKey){
        PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(dsaPrivateKey.getEncoded());

        try {
            KeyFactory keyFactory = KeyFactory.getInstance("DSA");
            PrivateKey privateKey = keyFactory.generatePrivate(pkcs8EncodedKeySpec);

            Signature signature = Signature.getInstance("SHA1withDSA");
            signature.initSign(privateKey);
            signature.update(data.getBytes());
            byte[] signatureResult = signature.sign();

            return signatureResult;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * @author: 韭菜馅糖包
     * @date: 2019/8/14 13:55
     * @since: JDK 1.8
     *
     * @description: 签名验证（公钥）
     * @param: [dsaPublicKey, signatureResult]
     * @return: java.lang.Boolean
     */
    private static Boolean signatureVerification(DSAPublicKey dsaPublicKey, byte[] signatureResult){
        X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(dsaPublicKey.getEncoded());
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("DSA");
            PublicKey publicKey = keyFactory.generatePublic(x509EncodedKeySpec);
            Signature signature = Signature.getInstance("SHA1withDSA");
            signature.initVerify(publicKey);
            signature.update(data.getBytes());
            return signature.verify(signatureResult);
        } catch (Exception e) {
            e.printStackTrace();
            return true;
        }
    }
}
