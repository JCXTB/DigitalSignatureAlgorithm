package code.dsa;

import java.security.interfaces.DSAPrivateKey;
import java.security.interfaces.DSAPublicKey;

public class DSAGenerateKey {
    private DSAPrivateKey dsaPrivateKey;

    private DSAPublicKey dsaPublicKey;

    public DSAGenerateKey(DSAPrivateKey dsaPrivateKey, DSAPublicKey dsaPublicKey) {
        this.dsaPrivateKey = dsaPrivateKey;
        this.dsaPublicKey = dsaPublicKey;
    }

    public DSAPrivateKey getDsaPrivateKey() {
        return dsaPrivateKey;
    }

    public void setDsaPrivateKey(DSAPrivateKey dsaPrivateKey) {
        this.dsaPrivateKey = dsaPrivateKey;
    }

    public DSAPublicKey getDsaPublicKey() {
        return dsaPublicKey;
    }

    public void setDsaPublicKey(DSAPublicKey dsaPublicKey) {
        this.dsaPublicKey = dsaPublicKey;
    }
}
